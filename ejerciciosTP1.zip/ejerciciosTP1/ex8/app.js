"use strict";

let num1;
num1 = parseInt(prompt("Ingrese un nro"));


if (num1 % 2 === 0) {
  console.log ("El numero ingresado es divisible por 2")
}
else if (num1 % 2 !== 0) {
  console.log ("El numero ingresado NO es divisible por 2")
}