"use strict";

let num1;
num1 = prompt("Ingrese un nro");

let num2;
num2 = prompt("Ingrese otro nro");


if (num1 > num2) {
    console.log("La mayor edad es la 1");
  }
