"use strict";

let num1;
num1 = parseInt(prompt("Ingrese un nro"));

let num2;
num2 = parseInt(prompt("Ingrese otro nro"));

let num3;
num3 = parseInt(prompt("Ingrese un tercer nro"));

if (num1 > num2 && num1 > num3) {
  console.log("El nro mayor es 1");
}
else if (num2 > num1 && num2> num3) {
  console.log("El nro mayor es 2");
}
else if (num3 > num1 && num3 > num2) {
  console.log("El nro mayor es 3");
}
