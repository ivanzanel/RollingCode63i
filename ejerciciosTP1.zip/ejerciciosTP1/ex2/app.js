"use strict";


document.write("Hello Word");
