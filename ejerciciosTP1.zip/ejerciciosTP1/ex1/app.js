"use strict";


window.alert("Un mensaje");
