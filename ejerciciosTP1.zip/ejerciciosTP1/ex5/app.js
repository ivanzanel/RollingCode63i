"use strict";


let num1;
num1 = prompt("Ingrese el primer numero");

let num2;
num2 = prompt("Ingrese el segundo numero");


console.log(Number(num1)+Number(num2));


