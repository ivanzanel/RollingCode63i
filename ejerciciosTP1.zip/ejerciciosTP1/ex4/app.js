"use strict";

let nombreUsuario = prompt("Ingrese su nombre de usuario");
console.log('Hola ' + nombreUsuario);


