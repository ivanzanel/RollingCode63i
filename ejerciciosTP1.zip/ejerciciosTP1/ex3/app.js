"use strict";


console.log(3 + 5);


